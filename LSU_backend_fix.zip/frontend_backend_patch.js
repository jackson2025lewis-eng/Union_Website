// Use this helper in membership.js, admin.js, and update.js.
// Do not call the Google Apps Script URL directly from browser code.
const BACKEND_URL = "/api/backend";

async function sendBackendRequest(payload) {
  const response = await fetch(BACKEND_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  let data;
  try {
    data = await response.json();
  } catch (error) {
    throw new Error("The membership backend returned an invalid response.");
  }

  if (!response.ok) {
    throw new Error(data.message || "Backend request failed.");
  }

  return data;
}

// Examples:
// sendBackendRequest({ action: "sendOTP", email });
// sendBackendRequest({ action: "verifyOTP", email, otp });
// sendBackendRequest({ action: "checkAdministratorAccess", email });
// sendBackendRequest({ action: "sendAdministratorOTP", email });
// sendBackendRequest({ action: "verifyAdministratorOTP", email, otp });
// sendBackendRequest({ action: "getDashboardData", sessionToken });
// sendBackendRequest({ action: "getDocumentUpdateInfo", token });
// sendBackendRequest({ action: "submitDocumentUpdate", token, file });
