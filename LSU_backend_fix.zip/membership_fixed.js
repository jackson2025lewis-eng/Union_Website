
document.addEventListener("DOMContentLoaded", () => {
  const BACKEND_URL = "/api/backend";
  const MAX_FILE = 5 * 1024 * 1024;
  const MAX_TOTAL = 15 * 1024 * 1024;

  let membershipType = null;
  let currentStepIndex = 0;
  let steps = [];
  let formData = { email: "" };
  let submitting = false;

  const $ = (id) => document.getElementById(id);

  const viewEmail = $("view-email");
  const viewOtp = $("view-otp");
  const viewType = $("view-type");
  const viewForm = $("view-form");

  const emailForm = $("email-form");
  const otpForm = $("otp-form");
  const btnTypeStudent = $("btn-type-student");
  const btnTypeAlumni = $("btn-type-alumni");
  const btnBackType = document.querySelector(".btn-back-type");
  const btnBackEmail = $("btn-back-email");
  const formTitle = $("form-title");
  const formWrapper = $("form-wrapper");
  const progressIndicator = $("progress-indicator");
  const btnPrev = $("btn-prev");
  const btnNext = $("btn-next");
  const btnSubmitFinal = $("btn-submit-final");
  const stepTemplates = $("step-templates");
  const sharedPrivacyReview = $("shared-privacy-review");

  if (!emailForm || !otpForm || !stepTemplates || !sharedPrivacyReview) {
    console.error("Membership form elements are missing.");
    return;
  }

  // The database name is Identification Photo.
  document.querySelectorAll('label[for*="passportPhoto"]').forEach(label => {
    label.innerHTML = label.innerHTML.replace(
      /Passport Size Photograph/gi,
      "Identification Photo"
    );
  });

  // Keep the current HTML structure, but add the discussed mandatory fields
  // that are missing from the older template.
  function ensureExtraFields() {
    ["student", "alumni"].forEach(type => {
      const personal = stepTemplates.querySelector(
        `.step-content[data-type="${type}"][data-step="1"]`
      );

      if (personal && !personal.querySelector('[name="dateOfBirth"]')) {
        const group = document.createElement("div");
        group.className = "form-group";
        group.innerHTML = `
          <label>Date of Birth <span class="required-star">★</span></label>
          <input type="date" name="dateOfBirth" required>
          <div class="error-msg">Date of Birth is required.</div>
        `;
        personal.querySelector(".form-row")?.appendChild(group);
      }
    });

    const alumniDocs = stepTemplates.querySelector(
      '.step-content[data-type="alumni"][data-step="4"] .form-row'
    );

    if (alumniDocs && !alumniDocs.querySelector('[name="passportDocument"]')) {
      const group = document.createElement("div");
      group.className = "form-group full-width";
      group.innerHTML = `
        <label>Passport Document <span class="required-star">★</span></label>
        <p class="field-desc">Upload your passport document as a PDF.</p>
        <input type="file" name="passportDocument" accept="application/pdf,.pdf" required>
        <div class="error-msg">Please upload your passport document as a PDF.</div>
      `;
      alumniDocs.insertBefore(group, alumniDocs.firstChild);
    }

    // Ensure alumni also has the same database field available when required
    // by the backend mapping.
  }

  ensureExtraFields();

  function showView(id) {
    document.querySelectorAll(".view-section").forEach(el => {
      el.classList.toggle("active", el.id === id);
      el.classList.toggle("hidden", el.id !== id);
    });
  }

  async function sendBackendRequest(payload) {
    const response = await fetch(BACKEND_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    let data;
    try {
      data = await response.json();
    } catch {
      throw new Error("The membership backend returned an invalid response.");
    }

    if (!response.ok) {
      throw new Error(data.message || "Backend request failed.");
    }

    return data;
  }

  function setButtonBusy(button, busy, busyText) {
    if (!button) return;
    if (busy) {
      button.dataset.originalText = button.textContent;
      button.disabled = true;
      button.textContent = busyText || "Processing...";
    } else {
      button.disabled = false;
      if (button.dataset.originalText) {
        button.textContent = button.dataset.originalText;
      }
    }
  }

  function showFormError(elementId, message) {
    const el = $(elementId);
    if (el) el.textContent = message;
  }

  // Email -> OTP
  emailForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const input = $("reg-email");
    const email = String(input?.value || "").trim().toLowerCase();

    if (!input?.checkValidity()) {
      showFormError("email-error", "Please enter a valid email address.");
      return;
    }

    const submitButton = emailForm.querySelector('button[type="submit"]');
    setButtonBusy(submitButton, true, "Sending...");

    try {
      const result = await sendBackendRequest({
        action: "sendOTP",
        email
      });

      if (!result.success) {
        throw new Error(result.message || "Unable to send verification code.");
      }

      formData.email = email;
      $("display-email").textContent = email;

      const otpInput = $("reg-otp");
      if (otpInput) {
        otpInput.maxLength = 7;
        otpInput.pattern = "LSU\\d{4}";
        otpInput.placeholder = "LSU1234";
      }

      showView("view-otp");
    } catch (error) {
      showFormError("email-error", error.message);
      console.error("Email verification error:", error);
    } finally {
      setButtonBusy(submitButton, false);
    }
  });

  // OTP -> membership type
  otpForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const otp = String($("reg-otp")?.value || "").trim().toUpperCase();

    if (!/^LSU\d{4}$/.test(otp)) {
      const input = $("reg-otp");
      if (input) {
        input.setCustomValidity("Enter the LSU code sent to your email, for example LSU2938.");
        input.reportValidity();
        input.setCustomValidity("");
      }
      return;
    }

    const submitButton = otpForm.querySelector('button[type="submit"]');
    setButtonBusy(submitButton, true, "Verifying...");

    try {
      const result = await sendBackendRequest({
        action: "verifyOTP",
        email: formData.email,
        otp
      });

      if (!result.success) {
        throw new Error(result.message || "Verification failed.");
      }

      showView("view-type");
    } catch (error) {
      console.error("OTP verification error:", error);
      alert(error.message);
    } finally {
      setButtonBusy(submitButton, false);
    }
  });

  btnBackEmail?.addEventListener("click", () => showView("view-email"));
  btnBackType?.addEventListener("click", () => showView("view-type"));

  btnTypeStudent?.addEventListener("click", () => initForm("student"));
  btnTypeAlumni?.addEventListener("click", () => initForm("alumni"));

  function generateYears() {
    const currentYear = new Date().getFullYear();

    formWrapper.querySelectorAll(".year-select").forEach(select => {
      const selected = select.value;
      select.innerHTML = '<option value="" disabled selected hidden></option>';

      for (let year = currentYear; year >= 1970; year--) {
        const option = document.createElement("option");
        option.value = String(year);
        option.textContent = String(year);
        if (String(year) === selected) option.selected = true;
        select.appendChild(option);
      }
    });
  }

  function initForm(type) {
    membershipType = type;
    currentStepIndex = 0;
    formData = { email: formData.email };

    formTitle.textContent =
      type === "student"
        ? "CURRENT STUDENT REGISTRATION"
        : "ALUMNI REGISTRATION";

    formWrapper.innerHTML = "";

    const typeSteps = Array.from(
      stepTemplates.querySelectorAll(
        `.step-content[data-type="${type}"]`
      )
    );

    const privacy = sharedPrivacyReview.cloneNode(true);
    privacy.removeAttribute("id");
    privacy.dataset.step = String(typeSteps.length + 1);
    privacy.dataset.type = type;

    steps = [
      ...typeSteps.map(step => step.cloneNode(true)),
      privacy
    ];

    steps.forEach((step, index) => {
      if (index !== 0) step.classList.add("hidden");
      formWrapper.appendChild(step);
    });

    generateYears();
    attachValidationListeners();
    updateProgressIndicator();
    updateButtons();
    showView("view-form");
  }

  function attachValidationListeners() {
    formWrapper.querySelectorAll("input, select").forEach(input => {
      input.addEventListener("change", () => {
        input.closest(".form-group")?.classList.remove("has-error");
      });
      input.addEventListener("input", () => {
        input.closest(".form-group")?.classList.remove("has-error");
      });
    });
  }

  function validateCurrentStep() {
    const step = steps[currentStepIndex];
    let valid = true;

    step.querySelectorAll(".form-group").forEach(g =>
      g.classList.remove("has-error")
    );

    step.querySelectorAll("input[required], select[required]").forEach(input => {
      if (!input.checkValidity()) {
        input.closest(".form-group")?.classList.add("has-error");
        valid = false;
        return;
      }

      if (input.name === "studyTo") {
        const from = step.querySelector('[name="studyFrom"]');
        if (from && from.value && Number(input.value) < Number(from.value)) {
          input.closest(".form-group")?.classList.add("has-error");
          valid = false;
        }
      }

      if (input.type === "file" && input.files.length) {
        const file = input.files[0];

        if (file.size > MAX_FILE) {
          input.closest(".form-group")?.classList.add("has-error");
          valid = false;
        }

        if (input.name === "efro" || input.name === "passportDocument") {
          if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
            input.closest(".form-group")?.classList.add("has-error");
            valid = false;
          }
        }

        if (input.name === "passportPhoto") {
          const name = file.name.toLowerCase();
          if (
            file.type !== "image/jpeg" &&
            !name.endsWith(".jpg") &&
            !name.endsWith(".jpeg")
          ) {
            input.closest(".form-group")?.classList.add("has-error");
            valid = false;
          }
        }
      }
    });

    return valid;
  }

  function updateProgressIndicator() {
    progressIndicator.innerHTML = "";

    steps.forEach((step, index) => {
      const item = document.createElement("div");
      item.className = "progress-step";

      if (index < currentStepIndex) item.classList.add("completed");
      if (index === currentStepIndex) item.classList.add("active");

      const dot = document.createElement("div");
      dot.className = "step-dot";
      dot.textContent = index < currentStepIndex ? "" : String(index + 1);

      const label = document.createElement("div");
      label.className = "step-label";
      label.textContent = step.dataset.label || "";

      item.append(dot, label);
      progressIndicator.appendChild(item);
    });
  }

  function updateButtons() {
    btnPrev?.classList.toggle("hidden", currentStepIndex === 0);

    if (currentStepIndex === steps.length - 1) {
      btnNext?.classList.add("hidden");
      btnSubmitFinal?.classList.remove("hidden");
      generateReview();
    } else {
      btnNext?.classList.remove("hidden");
      btnSubmitFinal?.classList.add("hidden");
    }
  }

  function collectFormData() {
    const inputs = formWrapper.querySelectorAll(
      "input:not([type=file]):not([type=checkbox]), select"
    );

    inputs.forEach(input => {
      formData[input.name] = input.value;
    });

    const consent = formWrapper.querySelector(
      'input[name="privacyConsent"]'
    );
    formData.privacyConsent = !!consent?.checked;
  }

  async function fileToPayload(file) {
    if (!file) return null;

    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Unable to read file."));
      reader.readAsDataURL(file);
    });

    const comma = String(dataUrl).indexOf(",");
    return {
      name: file.name,
      type: file.type,
      content: comma >= 0 ? String(dataUrl).slice(comma + 1) : String(dataUrl)
    };
  }

  async function collectFiles() {
    const files = {};

    const efro = formWrapper.querySelector('input[name="efro"]');
    const passportDocument = formWrapper.querySelector('input[name="passportDocument"]');
    const passportPhoto = formWrapper.querySelector('input[name="passportPhoto"]');

    if (efro?.files?.[0]) files.efroFile = await fileToPayload(efro.files[0]);
    if (passportDocument?.files?.[0]) {
      files.passportDocument = await fileToPayload(passportDocument.files[0]);
    }
    if (passportPhoto?.files?.[0]) {
      files.identificationPhoto = await fileToPayload(passportPhoto.files[0]);
    }

    return files;
  }

  async function submitApplication() {
    if (submitting) return;
    submitting = true;

    setButtonBusy(btnSubmitFinal, true, "Submitting...");

    try {
      collectFormData();

      if (!formData.dateOfBirth) {
        throw new Error("Date of Birth is required.");
      }

      if (!formData.privacyConsent) {
        throw new Error("You must accept the privacy notice.");
      }

      const files = await collectFiles();

      let total = 0;
      for (const key of Object.keys(files)) {
        const raw = files[key].content || "";
        const size = Math.floor(raw.length * 3 / 4);
        total += size;

        if (size > MAX_FILE) {
          throw new Error(
            "File size exceeds the 5 MB limit. Please upload a smaller file."
          );
        }
      }

      if (total > MAX_TOTAL) {
        throw new Error(
          "Total document/image size exceeds the 15 MB limit. Please reduce the file sizes."
        );
      }

      const data = {
        Email: formData.email,
        "Membership Type":
          membershipType === "student" ? "Current Student" : "Alumni",
        "First Name": formData.firstName,
        "Middle Name": formData.middleName || "",
        "Last Name": formData.lastName,
        Gender: formData.gender,
        "Date of Birth": formData.dateOfBirth,
        "Position / Role":
          membershipType === "student"
            ? formData.membershipStatusRole
            : formData.alumniPositionRole,
        "WhatsApp Number": formData.whatsappNumber || "",
        "Mobile Number": formData.mobileNumber || "",
        "Passport Number": formData.passportNumber || "",
        "College Registration Number":
          formData.collegeRegistrationNumber || "",
        University: formData.university || "",
        "Degree Type": formData.degreeType || "",
        "Study From": formData.studyFrom || "",
        "Study To": formData.studyTo || "",
        "Field of Studies": formData.fieldOfStudies || "",
        "Mother Name": formData.motherName || "",
        "Father Name": formData.fatherName || "",
        "Parents Contact": formData.parentsContact || "",
        "Graduation Date": formData.graduationDate || "",
        "Privacy Consent": formData.privacyConsent ? "Yes" : "No"
      };

      const result = await sendBackendRequest({
        action: "submitApplication",
        email: formData.email,
        data,
        ...files
      });

      if (!result.success) {
        throw new Error(result.message || "Application submission failed.");
      }

      alert(
        "Application submitted successfully.\n\nApplication ID: " +
        result.applicationId
      );

      window.location.reload();
    } catch (error) {
      console.error("Application submission error:", error);
      alert(error.message);
    } finally {
      submitting = false;
      setButtonBusy(btnSubmitFinal, false);
    }
  }

  btnNext?.addEventListener("click", () => {
    if (!validateCurrentStep()) return;

    collectFormData();

    steps[currentStepIndex].classList.add("hidden");
    currentStepIndex++;
    steps[currentStepIndex].classList.remove("hidden");

    updateProgressIndicator();
    updateButtons();
    viewForm.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  btnPrev?.addEventListener("click", () => {
    steps[currentStepIndex].classList.add("hidden");
    currentStepIndex--;
    steps[currentStepIndex].classList.remove("hidden");

    updateProgressIndicator();
    updateButtons();
  });

  btnSubmitFinal?.addEventListener("click", async () => {
    if (!validateCurrentStep()) return;
    await submitApplication();
  });

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function generateReview() {
    const container = formWrapper.querySelector(".review-content");
    if (!container) return;

    collectFormData();

    container.innerHTML = `
      <div class="review-section">
        <h4>Personal Information</h4>
        <div class="review-item"><div class="review-label">First Name:</div><div class="review-value">${escapeHtml(formData.firstName)}</div></div>
        <div class="review-item"><div class="review-label">Last Name:</div><div class="review-value">${escapeHtml(formData.lastName)}</div></div>
        <div class="review-item"><div class="review-label">Gender:</div><div class="review-value">${escapeHtml(formData.gender)}</div></div>
        <div class="review-item"><div class="review-label">Date of Birth:</div><div class="review-value">${escapeHtml(formData.dateOfBirth)}</div></div>
      </div>
      <div class="review-section">
        <h4>Academic Information</h4>
        <div class="review-item"><div class="review-label">University:</div><div class="review-value">${escapeHtml(formData.university)}</div></div>
        <div class="review-item"><div class="review-label">Degree:</div><div class="review-value">${escapeHtml(formData.degreeType)}</div></div>
        <div class="review-item"><div class="review-label">Field:</div><div class="review-value">${escapeHtml(formData.fieldOfStudies)}</div></div>
      </div>
      <div class="review-section">
        <h4>Documents</h4>
        <div class="review-item"><div class="review-label">Passport Document:</div><div class="review-value">Uploaded</div></div>
        <div class="review-item"><div class="review-label">Identification Photo:</div><div class="review-value">Uploaded</div></div>
        ${membershipType === "student" ? '<div class="review-item"><div class="review-label">EFRO:</div><div class="review-value">Uploaded</div></div>' : ""}
      </div>
    `;
  }

  generateYears();
  showView("view-email");
});
