const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbx65PRCECX0_xq-N9cpygnhG24rC0cYfW7V5PCYNMjEDmDSg9zuv3Mfy75QYeEtoLbfGw/exec';

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      message: 'Method not allowed.'
    });
  }

  try {
    const response = await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(req.body || {})
    });

    const text = await response.text();
    let data;

    try {
      data = JSON.parse(text);
    } catch (error) {
      console.error('Invalid Apps Script response:', text);
      return res.status(502).json({
        success: false,
        message: 'The membership backend returned an invalid response.'
      });
    }

    return res.status(response.ok ? 200 : 502).json(data);
  } catch (error) {
    console.error('Apps Script proxy error:', error);
    return res.status(502).json({
      success: false,
      message: 'Unable to connect to the membership backend. Please try again.'
    });
  }
}
